import Vapor

/// Register your application's routes here.
public func routes(_ router: Router) throws {
    // Basic "It works" example
    router.get { req in
        return "It works!"
    }
    
    // Let's start with the basic "Hello, world!"

    // and say your name

    // Let's add some custom routes
}

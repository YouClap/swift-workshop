import App

try app(.detect()).run()
